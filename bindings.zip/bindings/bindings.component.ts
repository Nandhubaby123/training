import { Component } from '@angular/core';

@Component({
  selector: 'app-bindings',
  templateUrl: './bindings.component.html',
  styleUrls: ['./bindings.component.css']
})
export class BindingsComponent {
  Username : any ='training';
  
  constructor()
  {
    setTimeout(()=>{
    },2000);
  }
  resetname()
  {
    this.Username = '';
  }
}
