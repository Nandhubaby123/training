import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuiltinDirectiveComponent } from './builtin-directive.component';

describe('BuiltinDirectiveComponent', () => {
  let component: BuiltinDirectiveComponent;
  let fixture: ComponentFixture<BuiltinDirectiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuiltinDirectiveComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuiltinDirectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
