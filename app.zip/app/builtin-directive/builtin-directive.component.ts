import { Component } from '@angular/core';

@Component({
  selector: 'app-builtin-directive',
  templateUrl: './builtin-directive.component.html',
  styleUrls: ['./builtin-directive.component.css']
})
export class BuiltinDirectiveComponent {

showpara: boolean = false;
para :any[]= [];


  getdetails()
  {
    this.showpara = !this.showpara;
    this.para.push(this.para.length + 1);
  }

}
