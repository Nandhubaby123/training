import { Component } from '@angular/core';

@Component({
  selector: 'app-bindings',
  templateUrl: './bindings.component.html',
  styleUrls: ['./bindings.component.css']
})
export class BindingsComponent {
  Username : any ='training';
  title = 'exercice2-udemy';
  userName = '';
  buttonDisabled = true;

  nameIsEmpty() {
    return this.userName.length === 0;
  }
  resetName() {
    this.userName = '';
  }
  constructor()
  {
    setTimeout(()=>{
    },2000);
  }
  resetname()
  {
    this.Username = '';
  }
}
